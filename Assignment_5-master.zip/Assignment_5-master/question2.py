length= int(input('Enter the length : '))
breadth = int(input('Enter the breadth : '))
if length == breadth:
    print("it is a square")
else:
    print("it is a rectangle")